// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require('hardhat');
// const ethers = hre.ethers;
const { updateContractAddresses } = require('../utils/contractsManagement');
// const provider = new ethers.getDefaultProvider(process.env.NETWORK);
const network = hre.hardhatArguments.network;
const { generatedWallets } = require('../utils/wallets');
const { JsonRpcProvider } = require('@ethersproject/providers');


async function main () {

  const provider = new JsonRpcProvider(process.env.PROVIDER_URL);

    this.signers = network
      ? generatedWallets(provider)
      : await ethers.getSigners();
    this.deployer = this.signers[0];
    this.sender = this.signers[1]
    this.receiver = this.signers[2];

  let cgt1m = await hre.ethers.getContractFactory('CGT1M');

  cgt1m = await cgt1m.deploy("www.google.com");
  await cgt1m.deployed();

  console.log('Contract deployed at:', cgt1m.address);

  updateContractAddresses(
    {
      cgt1m: cgt1m.address,
    },
    network,
  );
  
  console.log('************************************');
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
