/* eslint-disable no-unused-vars */
// We import Chai to use its asserting functions here.
const { expect } = require('chai');
const fs = require('fs');
const hre = require('hardhat');
const ethers = hre.ethers;
const { convertToBigNumber, convertFromBigNumber } = require('../utils/util');
const { generatedWallets } = require('../utils/wallets');
const { JsonRpcProvider } = require('@ethersproject/providers');
const path = require('path');

const network = process.argv[4];
const provider1 = ethers.getDefaultProvider();


describe('*** CGT1M Contract Testing ***', async function () {
  before(async function () {
    const provider = new JsonRpcProvider(process.env.PROVIDER_URL);

    this.signers = network
      ? generatedWallets(provider)
      : await ethers.getSigners();
    this.accont1 = this.signers[0];
    this.sender = this.signers[1]
    this.storeOwner = this.signers[2];
  });
  // `beforeEach` will run before each test, re-deploying the contract every
  // time. It receives a callback, which can be async.
  beforeEach(async function () {
    let cgt1m = await hre.ethers.getContractFactory('CGT1M');
    this.cgtERc721 = await cgt1m.deploy("wwww.google.com");
    await this.cgtERc721.deployed();

    console.log('Contract deployed at:', this.cgtERc721.address);
    }
  );

    it('It will check the length baseuri', async function () {
      const byteslength = await this.cgtERc721.bytesOfBaseURI();
    expect(byteslength).to.equal(15);
      })
      it('It should set new baseUri', async function () {
        await this.cgtERc721.setBaseURI("www.google.com");
        const byteslength = await this.cgtERc721.bytesOfBaseURI();
      expect(byteslength).to.equal(14);
        })
        it('It should set token range', async function () {
          await this.cgtERc721.setTokenRange(1000,2000);
          const tokenRangeStart = await this.cgtERc721.tokenRangeStart();
          const tokenRangeEnd = await this.cgtERc721.tokenRangeEnd();
        expect(tokenRangeStart).to.equal(1000);
        expect(tokenRangeEnd).to.equal(2000);
          })
          it('It should Mint the tokens', async function () {
            await this.cgtERc721.mint(this.accont1.address,1000001,33);
            const ownertokenId = await this.cgtERc721.ownerOf(1000001);
          expect(ownertokenId).to.equal(this.accont1.address);
          await this.cgtERc721.updateAttributes(1000001,44);
            const tokenAttributes = await this.cgtERc721.getAttributes(1000001);
          expect(tokenAttributes).to.equal(44);
            })
 });
    

